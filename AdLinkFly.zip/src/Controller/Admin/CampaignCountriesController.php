<?php

namespace App\Controller\Admin;

class CampaignCountriesController extends AppAdminController
{
}
