<?php

namespace App\Model\Table;

use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * @property \App\Model\Table\UsersTable|\Cake\ORM\Association\HasMany $Users
 *
 * @method \App\Model\Entity\Plan get($primaryKey, $options = [])
 * @method \App\Model\Entity\Plan newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Plan[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Plan|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Plan|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Plan patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Plan[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Plan findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 * @mixin \Cake\ORM\Behavior\TranslateBehavior
 */
class PlansTable extends Table
{
    public function initialize(array $config)
    {
        $this->addBehavior('Timestamp');
        $this->hasMany('Users');
        $this->addBehavior('Translate', ['fields' => ['title', 'description']]);
    }

    public function validationDefault(Validator $validator)
    {
        $validator
            ->notEmpty('title')
            ->boolean('enable', __('Choose a valid value.'))
            ->numeric('monthly_price', __('Choose a valid value.'))
            ->numeric('yearly_price', __('Choose a valid value.'))
            ->boolean('edit_link', __('Choose a valid value.'))
            ->boolean('edit_long_url', __('Choose a valid value.'))
            ->boolean('ads', __('Choose a valid value.'))
            ->boolean('direct', __('Choose a valid value.'))
            ->boolean('alias', __('Choose a valid value.'))
            ->boolean('referral', __('Choose a valid value.'))
            ->boolean('stats', __('Choose a valid value.'))
            ->boolean('api_quick', __('Choose a valid value.'))
            ->boolean('api_mass', __('Choose a valid value.'))
            ->boolean('api_full', __('Choose a valid value.'))
            ->boolean('api_developer', __('Choose a valid value.'))
            ->notEmpty('plan_replace', __('Choose a valid value.'));

        return $validator;
    }
}
